#include "network_manager.h"
#include "menu.h"
#include "xair_sync_manager.h"

static bool oscActive    = false;
static bool syncPending  = false;  // Sync wurde gestartet, Fader noch ausstehend
static bool fadersPushed = false;  // Fader wurden nach Sync bereits gesetzt

void networkBegin()
{
    oscActive    = false;
    syncPending  = false;
    fadersPushed = false;
}

void networkLoop()
{
    if (wifiConnected())
    {
        if (!oscActive)
        {
            oscReconnect();
            oscActive    = true;
            syncPending  = true;
            fadersPushed = false;

            DBG("Network: connected → starting full XAir sync");
            xairRequestStart();
        }
    }
    else
    {
        if (oscActive)
        {
            DBG("Network: connection lost");

            // Meter auf 0 setzen
            for (int i = 0; i < MAX_METERS; i++)
                mixerSetMeter(i, 0.0f);

            // Mixer-Info leeren
            mixerName[0] = '\0';
            mixerModel[0] = '\0';
        }
        oscActive    = false;
        syncPending  = false;
        fadersPushed = false;
    }

    // Sync abgeschlossen? Dann Fader auf Mixer-Werte fahren
    if (syncPending && !xairRequestRunning())
    {
        syncPending  = false;
        fadersPushed = true;

        DBG("Network: sync done → moving faders to mixer positions");
        syncFadersToMixer();
    }
}