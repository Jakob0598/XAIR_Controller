#pragma once
#include "config.h"

// VU-Meter Spaltenbreite (wird auch von display_manager genutzt)
#define VU_WIDTH   22

// Globale Redraw-Flags (können von OSC-Parser etc. gesetzt werden)
extern bool needRedraw;
extern bool needMiniRedraw;

// EQ Band Disable State (wird von display_manager gelesen)
// Literal values: MAX_CHANNELS=17, MAX_EQ_BANDS=5
extern float savedBandGain[17][5];
extern bool  bandDisabled[17][5];

void menuBegin();
void menuLoop();

// Fader auf aktuelle Mixer-Werte fahren (wird auch vom network_manager aufgerufen)
void syncFadersToMixer();
