#include "menu.h"

// ==========================
// REDRAW FLAGS
// ==========================
bool needRedraw      = false;   // Haupt-Display
bool needMiniRedraw  = false;   // Mini-Displays

// ==========================
// TAKEOVER STATE
// Korrekte Logik:
//   armed  = Motor hat sein Ziel erreicht → Fader liegt an der richtigen Position
//   active = User hat den Fader seitdem bewegt → ab jetzt werden Werte übertragen
// ==========================
struct FaderTakeover
{
    bool     armed    = false;
    bool     active   = false;
    uint16_t armPos   = 0;   // Position zum Zeitpunkt des Arming
};

static FaderTakeover takeover[FADER_COUNT];

// ==========================
// EQ BAND ENABLE/DISABLE STATE
// Merkt sich den Gain-Wert wenn ein Band deaktiviert wird
// ==========================
float savedBandGain[MAX_CHANNELS][MAX_EQ_BANDS];
bool  bandDisabled[MAX_CHANNELS][MAX_EQ_BANDS];

// ==========================
// SEITEN
// ==========================
enum MenuPage
{
    PAGE_MAIN,
    PAGE_CHANNEL_POPUP,
    PAGE_EQ,
    PAGE_EQ_TYPE_POPUP,
    PAGE_COMPRESSOR,
    PAGE_GATE,
    PAGE_SENDS,
    PAGE_ROUTING,
    PAGE_SCENES,
    PAGE_NETWORK,
    PAGE_SETTINGS
};

static struct
{
    MenuPage page          = PAGE_MAIN;
    int      selected      = 0;
    int      channel       = 1;
    int      eqBand        = 0;
    int      eqTypeSelection = 0;
    bool     redraw        = true;
} ui;

// ==========================
// MENÜ-EINTRÄGE
// ==========================
struct MenuItem {
    const char* label;
    const char* sublabel;
    uint16_t    accentR, accentG, accentB;
};

static const MenuItem menuItems[] = {
    { "Channel",    "Strip",          0,   180, 255  },  // hellblau
    { "EQ",         "Equalizer",      40,  210, 80   },  // grün
    { "Dynamics",   "Comp + Gate",    240, 130, 0    },  // orange
    { "Sends",      "Aux Routing",    180, 60,  255  },  // violett
    { "Routing",    "Patching",       0,   200, 180  },  // türkis
    { "Scenes",     "Snapshots",      255, 200, 0    },  // gelb
    { "Meters",     "Levels",         0,   160, 255  },  // blau
    { "Network",    "OSC / WiFi",     255, 80,  80   },  // rot
    { "Settings",   "System",         130, 130, 130  },  // grau
    { "Info",       "About",          80,  80,  80   },  // dunkelgrau
};

#define MENU_COUNT 10

// Helpers use VU_WIDTH from menu.h

// ==========================
// HELPERS
// ==========================
int mapFaderToChannel(int i)
{
    int ch = ui.channel + i;
    if (ch > mixerMaxChannels) ch -= mixerMaxChannels;
    return ch;
}

// ==========================
// TAKEOVER RESET
// ==========================
void resetTakeover()
{
    for (int i = 0; i < FADER_COUNT; i++)
    {
        takeover[i].armed  = false;
        takeover[i].active = false;
        takeover[i].armPos = 0;
    }
}

// ==========================
// FADER SYNC → Motor fährt auf Mixer-Wert
// ==========================
void syncFadersToMixer()
{
    for (int i = 0; i < FADER_COUNT; i++)
    {
        int ch = mapFaderToChannel(i);
        faderSet(i, (uint16_t)(channels[ch].fader * 4095.0f));
    }
    resetTakeover();
}

void syncFadersToEQ()
{
    int ch = ui.channel;

    if (ui.eqBand == 0)
    {
        // HPF: nur Fader 0 = Frequenz, Fader 1+2 unbenutzt → unten
        faderSet(0, (uint16_t)(channels[ch].hpfFreq * 4095.0f));
        faderSet(1, 0);
        faderSet(2, 0);
    }
    else
    {
        auto& b = channels[ch].eq[ui.eqBand];
        faderSet(0, (uint16_t)(b.gain * 4095.0f));
        faderSet(1, (uint16_t)(b.freq * 4095.0f));
        faderSet(2, (uint16_t)(b.q   * 4095.0f));
    }

    resetTakeover();
}

// ==========================
// FADER INPUT – Takeover
// ==========================
void processFaders()
{
    for (int i = 0; i < FADER_COUNT; i++)
    {
        uint16_t pos = faderGet(i);

        // --- Schritt 1: Arming ---
        // Fader muss DONE sein UND SETTLE_TIME abgelaufen sein
        // damit ADC-Rauschen nach Motor-Stop nicht sofort triggert
        if (!takeover[i].armed)
        {
            if (faders[i].isAtTarget()
                && (millis() - faders[i].doneTime() > TAKEOVER_SETTLE_MS))
            {
                takeover[i].armed  = true;
                takeover[i].armPos = pos;   // Stabile Position nach Settle
            }
            else
            {
                takeover[i].armPos = pos;   // Mitführen während Motor läuft
            }
            continue;   // NIEMALS Werte senden solange nicht armed!
        }

        // --- Schritt 2: User-Bewegung erkennen ---
        // Motor muss definitiv aus sein (nicht bewegen)
        if (!takeover[i].active)
        {
            // Falls Motor wieder gestartet wurde → zurücksetzen
            if (faders[i].isMoving())
            {
                takeover[i].armed  = false;
                takeover[i].active = false;
                continue;
            }

            uint16_t moved = (uint16_t)abs((int)pos - (int)takeover[i].armPos);
            if (moved > TAKEOVER_THRESHOLD)
            {
                takeover[i].active = true;
            }
            else
            {
                continue;   // Noch keine Bewegung → keine Werte senden
            }
        }

        // --- Schritt 3: Wert senden (nur wenn active!) ---
        float v = (float)pos / 4095.0f;

        // ---- CHANNEL / MAIN PAGE ----
        if (ui.page == PAGE_MAIN || ui.page == PAGE_CHANNEL_POPUP)
        {
            int ch = mapFaderToChannel(i);

            if (fabsf(channels[ch].fader - v) > 0.005f)
            {
                mixerSetFader(ch, v);

                char addr[32];
                snprintf(addr, sizeof(addr), "/ch/%02d/mix/fader", ch);
                oscSendFloat(addr, v);

                needRedraw     = true;
                needMiniRedraw = true;
            }
        }

        // ---- EQ PAGE ----
        else if (ui.page == PAGE_EQ)
        {
            int ch = ui.channel;

            if (ui.eqBand == 0)
            {
                // HPF: Nur Fader 0 = Frequenz
                if (i == 0 && fabsf(channels[ch].hpfFreq - v) > 0.005f)
                {
                    mixerSetHPFFreq(ch, v);

                    char addr[32];
                    snprintf(addr, sizeof(addr), "/ch/%02d/preamp/hpf", ch);
                    oscSendFloat(addr, v);

                    needRedraw     = true;
                    needMiniRedraw = true;
                }
                // Fader 1 und 2 haben auf HPF-Seite keine Funktion
            }
            else
            {
                auto& b = channels[ch].eq[ui.eqBand];

                if (i == 0 && fabsf(b.gain - v) > 0.005f)
                {
                    mixerSetEqGain(ch, ui.eqBand, v);

                    // Wenn Band disabled war und User den Gain-Fader bewegt → wieder aktivieren
                    if (bandDisabled[ch][ui.eqBand])
                    {
                        bandDisabled[ch][ui.eqBand] = false;
                    }

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/g", ch, ui.eqBand);
                    oscSendFloat(addr, v);

                    needRedraw     = true;
                    needMiniRedraw = true;
                }
                if (i == 1 && fabsf(b.freq - v) > 0.005f)
                {
                    mixerSetEqFreq(ch, ui.eqBand, v);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/f", ch, ui.eqBand);
                    oscSendFloat(addr, v);

                    needRedraw     = true;
                    needMiniRedraw = true;
                }
                if (i == 2 && fabsf(b.q - v) > 0.005f)
                {
                    mixerSetEqQ(ch, ui.eqBand, v);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/q", ch, ui.eqBand);
                    oscSendFloat(addr, v);

                    needRedraw     = true;
                    needMiniRedraw = true;
                }
            }
        }
    }
}

// ==========================
// MINI DISPLAY
// ==========================
static float scaleFreq(float v)
{
    float logMin = log10f(20.0f);
    float logMax = log10f(20000.0f);
    return powf(10.0f, logMin + v * (logMax - logMin));
}

static float scaleHPFFreq(float v)
{
    // HPF: 0.0-1.0 → 20-400 Hz
    float logMin = log10f(20.0f);
    float logMax = log10f(400.0f);
    return powf(10.0f, logMin + v * (logMax - logMin));
}

void updateMiniDisplays()
{
    if (ui.page == PAGE_EQ)
    {
        int ch = ui.channel;

        if (ui.eqBand == 0)
        {
            // HPF-Seite: Fader 0 = Freq, Fader 1+2 unbenutzt
            float freqHz = scaleHPFFreq(channels[ch].hpfFreq);
            char freqBuf[16];
            if (freqHz >= 100) snprintf(freqBuf, sizeof(freqBuf), "%.0f", freqHz);
            else               snprintf(freqBuf, sizeof(freqBuf), "%.1f", freqHz);

            // Channel VU auf Display 0
            float vu = (ch >= 1 && ch <= 16) ? meters[2 + (ch - 1)] : 0.0f;

            miniDisplayTextWithVU(0, channels[ch].hpfOn ? "HPF ON" : "HPF OFF",
                                  String(freqBuf) + "Hz", vu);

            // Display 1+2 ausgeschaltet
            miniDisplayClear(1);
            miniDisplayClear(2);

            // LEDs: Button 1/2 = HPF On/Off, Button 3 = EQ On/Off
            ledSet(0, channels[ch].hpfOn);
            ledSet(1, channels[ch].hpfOn);
            ledSet(2, channels[ch].eqOn);
        }
        else
        {
            auto& b = channels[ch].eq[ui.eqBand];

            float gainDb = -15.0f + b.gain * 30.0f;
            float freqHz = scaleFreq(b.freq);
            float qVal   = 10.0f * powf(0.03f, b.q);

            // Channel-VU NUR auf Display 0
            float vu = (ch >= 1 && ch <= 16) ? meters[2 + (ch - 1)] : 0.0f;

            // Gain-Anzeige mit dB-Vorzeichen + VU
            char gainBuf[16];
            snprintf(gainBuf, sizeof(gainBuf), "%+.1f", gainDb);
            miniDisplayTextWithVU(0, "GAIN", String(gainBuf) + "dB", vu);

            // Freq-Anzeige – schickes Param-Layout ohne VU
            char freqBuf[16];
            if (freqHz >= 10000)     snprintf(freqBuf, sizeof(freqBuf), "%.1fk", freqHz / 1000.0f);
            else if (freqHz >= 1000) snprintf(freqBuf, sizeof(freqBuf), "%.2fk", freqHz / 1000.0f);
            else                     snprintf(freqBuf, sizeof(freqBuf), "%.0f", freqHz);
            miniDisplayParam(1, "FREQ", freqBuf, "Hz");

            // Q-Anzeige – schickes Param-Layout ohne VU
            char qBuf[16];
            if (qVal >= 10.0f)      snprintf(qBuf, sizeof(qBuf), "%.1f", qVal);
            else if (qVal >= 1.0f)  snprintf(qBuf, sizeof(qBuf), "%.2f", qVal);
            else                    snprintf(qBuf, sizeof(qBuf), "%.3f", qVal);
            miniDisplayParam(2, "Q", qBuf);

            // LEDs: Button 1/2 = Band enabled, Button 3 = EQ On
            bool bEnabled = !bandDisabled[ch][ui.eqBand];
            ledSet(0, bEnabled);
            ledSet(1, bEnabled);
            ledSet(2, channels[ch].eqOn);
        }
    }
    else
    {
        // PAGE_MAIN / PAGE_CHANNEL_POPUP: pro Fader = Channel-Name + Channel-VU
        for (int i = 0; i < FADER_COUNT; i++)
        {
            int ch = mapFaderToChannel(i);

            // Meter-Slot: 0/1 = Master L/R, 2+ = Channel 1-16
            float vu = (ch >= 1 && ch <= 16) ? meters[2 + (ch - 1)] : 0.0f;

            // Formatierte Fader-dB-Anzeige
            float faderVal = channels[ch].fader;
            char dbBuf[12];
            if (faderVal < 0.001f) snprintf(dbBuf, sizeof(dbBuf), "-inf");
            else {
                float db = 20.0f * log10f(faderVal);
                snprintf(dbBuf, sizeof(dbBuf), "%.1fdB", db);
            }

            String line1 = "CH" + String(ch) + " " + String(channels[ch].name);
            String line2 = String(dbBuf);

            miniDisplayTextWithVU(i, line1, line2, vu);

            ledSet(i, channels[ch].mute);
        }
    }
}

// ==========================
// RETURN LED (blinkt außerhalb PAGE_MAIN)
// ==========================
void updateReturnLED()
{
    static uint32_t t = 0;
    static bool     s = false;

    if (ui.page == PAGE_MAIN)
    {
        ledSet(3, false);
        return;
    }

    if (millis() - t > 400)
    {
        t = millis();
        s = !s;
        ledSet(3, s);
    }
}

// ==========================
// INPUT
// ==========================
void handleInput()
{
    int d = encoderGetDelta();

    if (d != 0)
    {
        if (ui.page == PAGE_MAIN)
        {
            ui.selected = (ui.selected + d + MENU_COUNT) % MENU_COUNT;
        }
        else if (ui.page == PAGE_CHANNEL_POPUP)
        {
            ui.channel += d;
            if (ui.channel < 1)                ui.channel = mixerMaxChannels;
            if (ui.channel > mixerMaxChannels)  ui.channel = 1;

            syncFadersToMixer();
            needMiniRedraw = true;
        }
        else if (ui.page == PAGE_EQ)
        {
            ui.eqBand += d;
            if (ui.eqBand < 0) ui.eqBand = 4;
            if (ui.eqBand > 4) ui.eqBand = 0;

            syncFadersToEQ();
            needMiniRedraw = true;
        }
        else if (ui.page == PAGE_EQ_TYPE_POPUP)
        {
            ui.eqTypeSelection += d;
            if (ui.eqTypeSelection < 0) ui.eqTypeSelection = 5;
            if (ui.eqTypeSelection > 5) ui.eqTypeSelection = 0;
        }

        ui.redraw = true;
    }

    // ---- MUTE BUTTONS ----
    if (ui.page == PAGE_MAIN || ui.page == PAGE_CHANNEL_POPUP)
    {
        // Hauptmenü: Mute-Taster für Channels
        for (int i = 0; i < FADER_COUNT; i++)
        {
            if (buttonPressed((ButtonID)i))
            {
                int  ch = mapFaderToChannel(i);
                bool m  = !channels[ch].mute;

                mixerSetMute(ch, m);

                char addr[32];
                snprintf(addr, sizeof(addr), "/ch/%02d/mix/on", ch);
                oscSendInt(addr, m ? 0 : 1);   // XAir: on=0 bedeutet gemuted

                needMiniRedraw = true;
                ui.redraw      = true;
            }
        }
    }
    else if (ui.page == PAGE_EQ)
    {
        int ch = ui.channel;

        // ---- Button 1: HPF On/Off ODER Band 1-4 Enable/Disable ----
        if (buttonPressed(BUTTON_1))
        {
            if (ui.eqBand == 0)
            {
                // HPF On/Off Toggle
                bool newState = !channels[ch].hpfOn;
                mixerSetHPFOn(ch, newState);

                char addr[32];
                snprintf(addr, sizeof(addr), "/ch/%02d/preamp/hpon", ch);
                oscSendInt(addr, newState ? 1 : 0);
            }
            else
            {
                // Aktuelles EQ-Band Enable/Disable
                int b = ui.eqBand;
                if (!bandDisabled[ch][b])
                {
                    // Deaktivieren: Gain merken und auf 0.5 (0dB) setzen
                    savedBandGain[ch][b] = channels[ch].eq[b].gain;
                    bandDisabled[ch][b] = true;

                    mixerSetEqGain(ch, b, 0.5f);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/g", ch, b);
                    oscSendFloat(addr, 0.5f);
                }
                else
                {
                    // Aktivieren: gespeicherten Gain wiederherstellen
                    bandDisabled[ch][b] = false;
                    float restoreGain = savedBandGain[ch][b];

                    mixerSetEqGain(ch, b, restoreGain);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/g", ch, b);
                    oscSendFloat(addr, restoreGain);
                }

                // Fader auf neuen Gain-Wert fahren
                syncFadersToEQ();
            }

            needRedraw     = true;
            needMiniRedraw = true;
            ui.redraw      = true;
        }

        // ---- Button 2: (reserviert / gleiche Funktion wie Button 1 für Komfort) ----
        if (buttonPressed(BUTTON_2))
        {
            // Gleiche Logik wie Button 1 – zweiter Taster für selbe Funktion
            if (ui.eqBand == 0)
            {
                bool newState = !channels[ch].hpfOn;
                mixerSetHPFOn(ch, newState);

                char addr[32];
                snprintf(addr, sizeof(addr), "/ch/%02d/preamp/hpon", ch);
                oscSendInt(addr, newState ? 1 : 0);
            }
            else
            {
                int b = ui.eqBand;
                if (!bandDisabled[ch][b])
                {
                    savedBandGain[ch][b] = channels[ch].eq[b].gain;
                    bandDisabled[ch][b] = true;
                    mixerSetEqGain(ch, b, 0.5f);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/g", ch, b);
                    oscSendFloat(addr, 0.5f);
                }
                else
                {
                    bandDisabled[ch][b] = false;
                    float restoreGain = savedBandGain[ch][b];
                    mixerSetEqGain(ch, b, restoreGain);

                    char addr[48];
                    snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/g", ch, b);
                    oscSendFloat(addr, restoreGain);
                }
                syncFadersToEQ();
            }

            needRedraw     = true;
            needMiniRedraw = true;
            ui.redraw      = true;
        }

        // ---- Button 3: Gesamt-EQ On/Off ----
        if (buttonPressed(BUTTON_3))
        {
            bool newEqState = !channels[ch].eqOn;
            mixerSetEqOn(ch, newEqState);

            char addr[32];
            snprintf(addr, sizeof(addr), "/ch/%02d/eq/on", ch);
            oscSendInt(addr, newEqState ? 1 : 0);

            needRedraw     = true;
            needMiniRedraw = true;
            ui.redraw      = true;
        }
    }

    // ---- ENCODER BUTTON (Auswahl / Bestätigung) ----
    if (buttonPressed(BUTTON_ENCODER))
    {
        if (ui.page == PAGE_MAIN)
        {
            switch (ui.selected)
            {
                case 0: ui.page = PAGE_CHANNEL_POPUP;                             break;
                case 1: ui.page = PAGE_EQ;      syncFadersToEQ();                 break;
                case 2: ui.page = PAGE_COMPRESSOR;                                break;
                case 3: ui.page = PAGE_SENDS;                                     break;
                case 4: ui.page = PAGE_ROUTING;                                   break;
                case 5: ui.page = PAGE_SCENES;                                    break;
                case 6: ui.page = PAGE_MAIN;   /* Meters: kein Sub-Menü */        break;
                case 7: ui.page = PAGE_NETWORK;                                   break;
                case 8: ui.page = PAGE_SETTINGS;                                  break;
                default: break;
            }
            needMiniRedraw = true;
        }
        else if (ui.page == PAGE_EQ)
        {
            // Nur für Bänder 1-4 das Typ-Popup öffnen, NICHT für HPF (Band 0)
            if (ui.eqBand >= 1 && ui.eqBand <= 4)
            {
                ui.eqTypeSelection = (int)channels[ui.channel].eq[ui.eqBand].type;
                ui.page = PAGE_EQ_TYPE_POPUP;
            }
        }
        else if (ui.page == PAGE_EQ_TYPE_POPUP)
        {
            EqType newType = (EqType)ui.eqTypeSelection;
            channels[ui.channel].eq[ui.eqBand].type = newType;
            char addr[48];
            snprintf(addr, sizeof(addr), "/ch/%02d/eq/%d/t", ui.channel, ui.eqBand);
            oscSendInt(addr, (int)newType);
            ui.page = PAGE_EQ;
        }
        else
        {
            ui.page = PAGE_MAIN;
            syncFadersToMixer();
            needMiniRedraw = true;
        }

        ui.redraw = true;
    }

    // ---- RETURN BUTTON ----
    if (buttonPressed(BUTTON_RETURN))
    {
        if (ui.page == PAGE_EQ_TYPE_POPUP)
            ui.page = PAGE_EQ;
        else
        {
            ui.page = PAGE_MAIN;
            syncFadersToMixer();
            needMiniRedraw = true;
        }
        ui.redraw = true;
    }
}

// ==========================
// DRAW HELPERS
// ==========================

// Farbiger Akzentpunkt links vom Menü-Label
static void drawAccentDot(int x, int y, int r, int g, int b, bool filled)
{
    uint16_t col = tft.color565(r, g, b);
    if (filled)
    {
        tft.fillCircle(x, y, 4, col);
        tft.drawCircle(x, y, 4, TFT_WHITE);
    }
    else
    {
        tft.fillCircle(x, y, 4, tft.color565(20, 20, 20));
        tft.drawCircle(x, y, 4, col);
    }
}

// Horizontale Trennlinie mit sanftem Verlauf an den Rändern
static void drawSeparator(int y, int x0, int x1)
{
    uint16_t col = tft.color565(40, 40, 40);
    // Hauptlinie
    tft.drawFastHLine(x0 + 4, y, x1 - x0 - 8, col);
    // Weicher Einlauf/Auslauf
    tft.drawPixel(x0 + 2, y, tft.color565(15, 15, 15));
    tft.drawPixel(x0 + 3, y, tft.color565(25, 25, 25));
    tft.drawPixel(x1 - 3, y, tft.color565(25, 25, 25));
    tft.drawPixel(x1 - 2, y, tft.color565(15, 15, 15));
}

// ==========================
// MAIN MENÜ
// ==========================
void drawMenu()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    const int ITEM_H    = 21;
    const int START_Y   = 22;
    const int PAD_LEFT  = 18;
    const int LEFT_M    = 3;

    tft.fillRect(0, START_Y, CONTENT_W, tft.height() - START_Y, TFT_BLACK);

    for (int i = 0; i < MENU_COUNT; i++)
    {
        int y    = START_Y + i * ITEM_H;
        bool sel = (i == ui.selected);

        uint16_t accentCol = tft.color565(
            menuItems[i].accentR,
            menuItems[i].accentG,
            menuItems[i].accentB
        );
        uint16_t dimCol = tft.color565(
            menuItems[i].accentR / 4,
            menuItems[i].accentG / 4,
            menuItems[i].accentB / 4
        );

        if (sel)
        {
            tft.fillRect(LEFT_M, y, CONTENT_W - LEFT_M, ITEM_H - 1, dimCol);
            tft.fillRect(LEFT_M, y + 1, 3, ITEM_H - 3, accentCol);
        }
        else
        {
            tft.fillRect(0, y, CONTENT_W, ITEM_H - 1, TFT_BLACK);
            tft.fillRect(LEFT_M, y + 1, 2, ITEM_H - 3, tft.color565(28, 28, 28));
        }

        drawAccentDot(LEFT_M + 8, y + ITEM_H / 2, menuItems[i].accentR,
                      menuItems[i].accentG, menuItems[i].accentB, sel);

        tft.setTextSize(1);

        if (sel)
            tft.setTextColor(TFT_WHITE, dimCol);
        else
            tft.setTextColor(tft.color565(160, 160, 160), TFT_BLACK);

        tft.setCursor(PAD_LEFT, y + 4);
        tft.print(menuItems[i].label);

        tft.setTextColor(sel ? accentCol : tft.color565(70, 70, 70),
                         sel ? dimCol    : TFT_BLACK);
        tft.setCursor(PAD_LEFT + strlen(menuItems[i].label) * 6 + 4, y + 4);
        tft.print(menuItems[i].sublabel);

        if (i == 0)
        {
            char buf[8];
            snprintf(buf, sizeof(buf), "CH%d", ui.channel);
            tft.setTextColor(accentCol, sel ? dimCol : TFT_BLACK);
            tft.setCursor(CONTENT_W - strlen(buf) * 6 - 6, y + 4);
            tft.print(buf);
        }

        if (i < MENU_COUNT - 1)
            drawSeparator(y + ITEM_H - 1, 6, CONTENT_W - 6);
    }

    tft.drawFastVLine(0, START_Y + 6, tft.height() - START_Y - 12, tft.color565(22, 22, 22));
    tft.drawFastVLine(CONTENT_W - 1, START_Y, tft.height() - START_Y, tft.color565(20, 20, 20));

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// CHANNEL POPUP
// ==========================
void drawChannelPopup()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    const int w = 160, h = 90;
    int x = (CONTENT_W - w) / 2;
    int y = (tft.height() - h) / 2;

    // Schatten
    tft.fillRect(x + 3, y + 3, w, h, tft.color565(10, 10, 10));

    // Hintergrund
    tft.fillRect(x, y, w, h, tft.color565(25, 25, 25));
    tft.drawRect(x, y, w, h, tft.color565(0, 180, 255));

    // Titel-Header
    tft.fillRect(x, y, w, 18, tft.color565(0, 60, 90));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(0, 180, 255), tft.color565(0, 60, 90));
    tft.setCursor(x + 8, y + 5);
    tft.print("SELECT CHANNEL");

    // Kanal-Nummer groß
    tft.setTextSize(3);
    tft.setTextColor(TFT_WHITE, tft.color565(25, 25, 25));
    char buf[8];
    snprintf(buf, sizeof(buf), "%02d", ui.channel);
    int tw = strlen(buf) * 18;
    tft.setCursor(x + (w - tw) / 2, y + 30);
    tft.print(buf);

    // Channel-Name
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(120, 120, 120), tft.color565(25, 25, 25));
    const char* chName = channels[ui.channel].name;
    if (strlen(chName) > 0)
    {
        int nw = strlen(chName) * 6;
        tft.setCursor(x + (w - nw) / 2, y + 66);
        tft.print(chName);
    }

    // Pfeil-Hinweis
    tft.setTextColor(tft.color565(60, 60, 60), tft.color565(25, 25, 25));
    tft.setCursor(x + 6, y + 76);
    tft.print("< Encoder >");

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// EQ VIEW – Split in Teilfunktionen für flackerfreies Redraw
// ==========================

// Nur EQ-Header (Leiste oben)
void drawEQHeader()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;

    tft.fillRect(0, 20, CONTENT_W, 18, tft.color565(20, 20, 20));
    tft.drawFastHLine(0, 38, CONTENT_W, tft.color565(10, 10, 10));

    tft.setTextSize(1);
    tft.setTextColor(tft.color565(40, 210, 80), tft.color565(20, 20, 20));
    tft.setCursor(8, 24);
    tft.print("EQ");

    tft.setTextColor(TFT_WHITE, tft.color565(20, 20, 20));
    char buf[16];
    snprintf(buf, sizeof(buf), "CH %02d", ui.channel);
    tft.setCursor(30, 24);
    tft.print(buf);

    const char* chName = channels[ui.channel].name;
    if (strlen(chName) > 0)
    {
        tft.setTextColor(tft.color565(80, 80, 80), tft.color565(20, 20, 20));
        tft.setCursor(80, 24);
        tft.print(chName);
    }

    bool eqOn = channels[ui.channel].eqOn;
    int pillX = CONTENT_W - 26;
    int pillY = 22;
    int pillW = 22;
    int pillH = 11;
    uint16_t pillBg = eqOn ? tft.color565(20, 80, 30) : tft.color565(35, 35, 35);
    uint16_t pillFg = eqOn ? tft.color565(40, 210, 80) : tft.color565(70, 70, 70);
    tft.fillRect(pillX + 1, pillY, pillW - 2, pillH, pillBg);
    tft.fillRect(pillX, pillY + 1, pillW, pillH - 2, pillBg);
    tft.setTextColor(pillFg, pillBg);
    tft.setCursor(pillX + 3, pillY + 2);
    tft.print(eqOn ? "ON" : "OF");

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// Nur EQ-Tabs unten + Hint-Text
void drawEQTabs()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    const char* labels[] = { "HPF", "B1", "B2", "B3", "B4" };
    uint16_t bgColors[5] = {
        tft.color565(160, 160, 160),
        EQ_COLOR_BAND1,
        EQ_COLOR_BAND2,
        EQ_COLOR_BAND3,
        EQ_COLOR_BAND4
    };

    int tabY = tft.height() - 20;
    tft.fillRect(0, tabY - 2, CONTENT_W, 22, tft.color565(10, 10, 10));

    ChannelState& c = channels[ui.channel];
    int ch = ui.channel;

    tft.setTextSize(1);

    for (int i = 0; i < 5; i++)
    {
        int tabMargin = 4;
        int tabX = tabMargin + i * ((CONTENT_W - tabMargin * 2) / 5);
        int tabW = (CONTENT_W - tabMargin * 2) / 5 - 1;

        uint16_t bandBg = bgColors[i];

        bool dimmed = false;
        if (i == 0 && !c.hpfOn)
            dimmed = true;
        else if (i > 0 && (!c.eqOn || bandDisabled[ch][i]))
            dimmed = true;

        if (dimmed)
            bandBg = tft.color565(50, 50, 50);

        bool active = (i == ui.eqBand);

        if (active)
        {
            tft.fillRect(tabX, tabY - 2, tabW, 19, bandBg);
            tft.setTextColor(dimmed ? tft.color565(120, 120, 120) : TFT_BLACK, bandBg);
        }
        else
        {
            tft.fillRect(tabX, tabY - 2, tabW, 19, tft.color565(20, 20, 20));
            tft.drawRect(tabX, tabY - 2, tabW, 19, bandBg);
            tft.setTextColor(bandBg, tft.color565(20, 20, 20));
        }

        int lw = strlen(labels[i]) * 6;
        tft.setCursor(tabX + (tabW - lw) / 2, tabY + 3);
        tft.print(labels[i]);

        if (i > 0 && bandDisabled[ch][i])
        {
            tft.setTextColor(tft.color565(200, 60, 60), active ? bandBg : tft.color565(20, 20, 20));
            tft.setCursor(tabX + tabW - 8, tabY - 1);
            tft.print("x");
        }
    }

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// Nur EQ-Kurven neuzeichnen (Plotbereich)
void drawEQPlot()
{
    displayDrawEq(ui.channel);
}

// Vollständiger EQ-Aufbau (nur bei Seitenwechsel oder Band-Wechsel)
void drawEQ()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;

    // Nur den Bereich zwischen Header und Tabs löschen (Plot-Bereich)
    tft.fillRect(0, 38, CONTENT_W, tft.height() - 38 - 33, TFT_BLACK);

    drawEQHeader();
    drawEQPlot();
    drawEQTabs();
}

// ==========================
// EQ TYP POPUP
// ==========================
void drawEQTypePopup()
{
    const char* types[] = { "LCUT", "LSHV", "PEQ", "VEQ", "HSHV", "HCUT" };
    const char* typeDesc[] = {
        "Low Cut Filter",
        "Low Shelf",
        "Parametric EQ",
        "Vintage EQ",
        "High Shelf",
        "High Cut Filter"
    };

    const int CONTENT_W = tft.width() - VU_WIDTH;
    const int w = 170, h = 120;
    int x = (CONTENT_W - w) / 2;
    int y = (tft.height() - h) / 2;

    // Schatten
    tft.fillRect(x + 3, y + 3, w, h, tft.color565(10, 10, 10));

    // Box
    tft.fillRect(x, y, w, h, tft.color565(22, 22, 22));
    tft.drawRect(x, y, w, h, tft.color565(40, 210, 80));

    // Header
    tft.fillRect(x, y, w, 16, tft.color565(20, 80, 30));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(40, 210, 80), tft.color565(20, 80, 30));
    tft.setCursor(x + 6, y + 4);
    tft.print("EQ BAND TYPE");

    for (int i = 0; i < 6; i++)
    {
        int yy = y + 18 + i * 16;
        bool sel = (i == ui.eqTypeSelection);

        if (sel)
        {
            tft.fillRect(x + 2, yy, w - 4, 15, tft.color565(20, 80, 30));
            tft.drawRect(x + 2, yy, w - 4, 15, tft.color565(40, 210, 80));
            tft.setTextColor(TFT_WHITE, tft.color565(20, 80, 30));
        }
        else
        {
            tft.fillRect(x + 2, yy, w - 4, 15, tft.color565(22, 22, 22));
            tft.setTextColor(tft.color565(100, 100, 100), tft.color565(22, 22, 22));
        }

        tft.setCursor(x + 8, yy + 3);
        tft.print(types[i]);

        if (sel)
        {
            tft.setTextColor(tft.color565(40, 210, 80), tft.color565(20, 80, 30));
            tft.setCursor(x + 46, yy + 3);
            tft.print(typeDesc[i]);
        }
    }

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// DYNAMICS (COMPRESSOR + GATE)
// ==========================
void drawDynamics()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    tft.fillRect(0, 20, CONTENT_W, tft.height() - 20, TFT_BLACK);

    // Header
    tft.fillRect(0, 20, CONTENT_W, 16, tft.color565(20, 20, 20));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(240, 130, 0), tft.color565(20, 20, 20));
    tft.setCursor(5, 24);
    tft.print("DYNAMICS");
    tft.setTextColor(TFT_WHITE, tft.color565(20, 20, 20));
    char buf[16];
    snprintf(buf, sizeof(buf), " CH %02d", ui.channel);
    tft.print(buf);

    ChannelState& c = channels[ui.channel];

    // ---- COMPRESSOR ----
    int cy = 42;
    tft.fillRect(4, cy, CONTENT_W - 8, 82, tft.color565(18, 18, 18));
    tft.drawRect(4, cy, CONTENT_W - 8, 82, tft.color565(240, 130, 0));
    tft.fillRect(4, cy, CONTENT_W - 8, 14, tft.color565(80, 40, 0));
    tft.setTextColor(tft.color565(240, 130, 0), tft.color565(80, 40, 0));
    tft.setCursor(8, cy + 3);
    tft.print("COMPRESSOR");

    auto drawParam = [&](int px, int py, const char* name, float val, const char* unit)
    {
        tft.setTextColor(tft.color565(100, 100, 100), tft.color565(18, 18, 18));
        tft.setCursor(px, py);
        tft.print(name);
        tft.setTextColor(TFT_WHITE, tft.color565(18, 18, 18));
        char vbuf[16];
        snprintf(vbuf, sizeof(vbuf), "%.1f%s", val, unit);
        tft.setCursor(px, py + 10);
        tft.print(vbuf);
    };

    // Threshold, Ratio, Attack, Release
    float thr  = -60.0f + c.comp.threshold * 60.0f;
    float rat  = 1.0f + c.comp.ratio * 9.0f;
    float atk  = c.comp.attack  * 200.0f;
    float rel  = c.comp.release * 800.0f;

    drawParam(10,  cy + 18, "THR",  thr, "dB");
    drawParam(62,  cy + 18, "RATIO", rat, ":1");
    drawParam(120, cy + 18, "ATK",  atk, "ms");
    drawParam(175, cy + 18, "REL",  rel, "ms");

    // Mini Gain-Reduction Balken
    tft.drawFastHLine(8, cy + 56, CONTENT_W - 16, tft.color565(50, 50, 50));
    tft.setTextColor(tft.color565(70, 70, 70), tft.color565(18, 18, 18));
    tft.setCursor(8, cy + 60);
    tft.print("GR");
    int grBar = (int)(meters[0] * (CONTENT_W - 30));
    tft.fillRect(24, cy + 60, CONTENT_W - 30, 8, tft.color565(15, 15, 15));
    if (grBar > 0)
        tft.fillRect(24, cy + 60, grBar, 8, tft.color565(240, 130, 0));

    // ---- GATE ----
    int gy = cy + 90;
    tft.fillRect(4, gy, CONTENT_W - 8, 52, tft.color565(18, 18, 18));
    tft.drawRect(4, gy, CONTENT_W - 8, 52, tft.color565(180, 60, 255));
    tft.fillRect(4, gy, CONTENT_W - 8, 14, tft.color565(50, 15, 80));
    tft.setTextColor(tft.color565(180, 60, 255), tft.color565(50, 15, 80));
    tft.setCursor(8, gy + 3);
    tft.print("GATE");

    float gThr = -80.0f + c.gate.threshold * 80.0f;
    drawParam(10, gy + 18, "THR", gThr, "dB");

    tft.setTextColor(tft.color565(60, 60, 60), tft.color565(18, 18, 18));
    tft.setCursor(8, gy + 36);
    tft.print("Use Faders: Threshold");

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// SENDS VIEW
// ==========================
void drawSends()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    tft.fillRect(0, 20, CONTENT_W, tft.height() - 20, TFT_BLACK);

    tft.fillRect(0, 20, CONTENT_W, 16, tft.color565(20, 20, 20));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(180, 60, 255), tft.color565(20, 20, 20));
    tft.setCursor(5, 24);
    tft.print("SENDS");
    tft.setTextColor(TFT_WHITE, tft.color565(20, 20, 20));
    char buf[16];
    snprintf(buf, sizeof(buf), " CH %02d", ui.channel);
    tft.print(buf);

    ChannelState& c = channels[ui.channel];

    // Pro Bus ein Balken
    int busCount = constrain(mixerMaxBuses, 1, 6);
    int barW     = (CONTENT_W - 16) / busCount - 4;
    int barH     = tft.height() - 60;

    for (int b = 1; b <= busCount; b++)
    {
        int bx  = 8 + (b - 1) * (barW + 4);
        int by  = 38;
        float v = (b < MAX_BUSES) ? c.sends[b] : 0.0f;

        // Rahmen
        tft.fillRect(bx, by, barW, barH, tft.color565(15, 15, 15));
        tft.drawRect(bx, by, barW, barH, tft.color565(50, 50, 50));

        // Füllstand
        int filled = (int)(v * barH);
        tft.fillRect(bx + 1, by + barH - filled, barW - 2, filled,
                     tft.color565(120, 40, 200));

        // Label
        char lbuf[4];
        snprintf(lbuf, sizeof(lbuf), "A%d", b);
        tft.setTextColor(tft.color565(120, 120, 120), TFT_BLACK);
        tft.setCursor(bx + (barW - 12) / 2, by + barH + 3);
        tft.print(lbuf);

        // dB-Wert
        float db = (v > 0.001f) ? 20.0f * log10f(v) : -99.0f;
        tft.setTextColor(tft.color565(180, 60, 255), TFT_BLACK);
        tft.setCursor(bx, by + barH + 13);
        if (db < -50.0f) tft.print("-inf");
        else { char dbuf[8]; snprintf(dbuf, sizeof(dbuf), "%.0f", db); tft.print(dbuf); }
    }

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// ROUTING (Platzhalter mit Hinweis)
// ==========================
void drawInfoPage(const char* title, uint16_t accentCol, const char* line1, const char* line2)
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    tft.fillRect(0, 20, CONTENT_W, tft.height() - 20, TFT_BLACK);

    tft.fillRect(0, 20, CONTENT_W, 16, tft.color565(20, 20, 20));
    tft.setTextSize(1);
    tft.setTextColor(accentCol, tft.color565(20, 20, 20));
    tft.setCursor(5, 24);
    tft.print(title);

    // Zentrierter Inhalt
    int midX = CONTENT_W / 2;
    int midY = tft.height() / 2;

    // Icon-Kreis
    tft.drawCircle(midX, midY - 20, 22, accentCol);
    tft.setTextColor(accentCol, TFT_BLACK);
    tft.setCursor(midX - 3, midY - 24);
    tft.print("i");

    tft.setTextColor(tft.color565(120, 120, 120), TFT_BLACK);
    int lw1 = strlen(line1) * 6;
    tft.setCursor(midX - lw1 / 2, midY + 8);
    tft.print(line1);

    tft.setTextColor(tft.color565(60, 60, 60), TFT_BLACK);
    int lw2 = strlen(line2) * 6;
    tft.setCursor(midX - lw2 / 2, midY + 22);
    tft.print(line2);

    // Return-Hinweis
    tft.setTextColor(tft.color565(45, 45, 45), TFT_BLACK);
    tft.setCursor(midX - 36, tft.height() - 16);
    tft.print("RETURN = back");

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// NETWORK
// ==========================
void drawNetwork()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    tft.fillRect(0, 20, CONTENT_W, tft.height() - 20, TFT_BLACK);

    tft.fillRect(0, 20, CONTENT_W, 16, tft.color565(20, 20, 20));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(255, 80, 80), tft.color565(20, 20, 20));
    tft.setCursor(5, 24);
    tft.print("NETWORK");

    auto drawRow = [&](int y, const char* label, const char* value, uint16_t valCol)
    {
        tft.setTextColor(tft.color565(70, 70, 70), TFT_BLACK);
        tft.setCursor(8, y);
        tft.print(label);
        tft.setTextColor(valCol, TFT_BLACK);
        tft.setCursor(80, y);
        tft.print(value);
        tft.drawFastHLine(8, y + 10, CONTENT_W - 16, tft.color565(25, 25, 25));
    };

    // WiFi Status
    bool wifiOk = wifiConnected();
    drawRow(42,  "WiFi",    wifiOk ? "Connected"    : "Disconnected",
            wifiOk ? tft.color565(40, 210, 80) : tft.color565(255, 80, 80));

    // IP
    char ipBuf[24] = "---";
    if (wifiOk) WiFi.localIP().toString().toCharArray(ipBuf, sizeof(ipBuf));
    drawRow(56,  "IP",      ipBuf, tft.color565(180, 180, 180));

    // XAir
    bool xairOk = isSystemReady();
    drawRow(70,  "XAir",   xairOk ? mixerModel : "Not found",
            xairOk ? tft.color565(40, 210, 80) : tft.color565(255, 80, 80));

    // Mixer Name
    drawRow(84,  "Name",   strlen(mixerName) > 0 ? mixerName : "---",
            tft.color565(180, 180, 180));

    // SSID
    char ssid[32] = "---";
    if (wifiOk) WiFi.SSID().toCharArray(ssid, sizeof(ssid));
    drawRow(98,  "SSID",   ssid,  tft.color565(180, 180, 180));

    // RSSI
    char rssiBuf[12] = "---";
    if (wifiOk) snprintf(rssiBuf, sizeof(rssiBuf), "%d dBm", WiFi.RSSI());
    drawRow(112, "RSSI",   rssiBuf, tft.color565(180, 180, 180));

    // OSC Port
    char portBuf[12];
    snprintf(portBuf, sizeof(portBuf), "%d", settings.sendPort);
    drawRow(126, "OSC Port", portBuf, tft.color565(180, 180, 180));

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// SETTINGS
// ==========================
void drawSettings()
{
    const int CONTENT_W = tft.width() - VU_WIDTH;
    tft.fillRect(0, 20, CONTENT_W, tft.height() - 20, TFT_BLACK);

    tft.fillRect(0, 20, CONTENT_W, 16, tft.color565(20, 20, 20));
    tft.setTextSize(1);
    tft.setTextColor(tft.color565(130, 130, 130), tft.color565(20, 20, 20));
    tft.setCursor(5, 24);
    tft.print("SETTINGS");

    const char* items[] = {
        "Brightness",
        "XAir IP",
        "OSC Port",
        "WiFi SSID",
        "WiFi Pass",
        "Calibrate Faders",
        "Factory Reset"
    };
    const char* hints[] = {
        "Display backlight",
        "Target mixer IP",
        "Default: 10024",
        "Network name",
        "WPA key",
        "Move faders to limits",
        "Clear all settings"
    };

    for (int i = 0; i < 7; i++)
    {
        int iy = 40 + i * 26;
        tft.fillRect(4, iy, CONTENT_W - 8, 24, tft.color565(18, 18, 18));
        tft.drawRect(4, iy, CONTENT_W - 8, 24, tft.color565(35, 35, 35));

        tft.setTextColor(TFT_WHITE, tft.color565(18, 18, 18));
        tft.setCursor(10, iy + 4);
        tft.print(items[i]);

        tft.setTextColor(tft.color565(60, 60, 60), tft.color565(18, 18, 18));
        tft.setCursor(10, iy + 14);
        tft.print(hints[i]);
    }

    tft.setTextColor(tft.color565(50, 50, 50), TFT_BLACK);
    tft.setCursor(8, tft.height() - 12);
    tft.print("Use WebUI for full config");

    tft.setTextSize(2);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
}

// ==========================
// LOOP
// ==========================
void menuLoop()
{
    handleInput();
    processFaders();

    // ---- EQ-Seite: differenziertes Redraw ----
    if (ui.page == PAGE_EQ || ui.page == PAGE_EQ_TYPE_POPUP)
    {
        if (ui.redraw)
        {
            // Vollständiger Neuaufbau (Seitenwechsel, Band-Wechsel, Button)
            drawEQ();
            if (ui.page == PAGE_EQ_TYPE_POPUP)
                drawEQTypePopup();
            ui.redraw  = false;
            needRedraw = false;
        }
        else if (needRedraw)
        {
            // Nur EQ-Kurven neuzeichnen (Fader bewegt → Parameter geändert)
            drawEQPlot();
            needRedraw = false;
        }
    }
    // ---- Alle anderen Seiten: wie bisher ----
    else if (ui.redraw || needRedraw)
    {
        switch (ui.page)
        {
            case PAGE_MAIN:
                drawMenu();
                break;
            case PAGE_CHANNEL_POPUP:
                drawMenu();
                drawChannelPopup();
                break;
            case PAGE_COMPRESSOR:
            case PAGE_GATE:
                drawDynamics();
                break;
            case PAGE_SENDS:
                drawSends();
                break;
            case PAGE_ROUTING:
                drawInfoPage("ROUTING", tft.color565(0, 200, 180),
                             "Coming soon", "Use WebUI for routing");
                break;
            case PAGE_SCENES:
                drawInfoPage("SCENES", tft.color565(255, 200, 0),
                             "Snapshot support", "Coming soon");
                break;
            case PAGE_NETWORK:
                drawNetwork();
                break;
            case PAGE_SETTINGS:
                drawSettings();
                break;
            default:
                drawMenu();
                break;
        }

        ui.redraw  = false;
        needRedraw = false;
    }

    updateReturnLED();

    displayDrawStatusBar();
    displayDrawStereoVUMeter(0, 1);

    static uint32_t miniTimer = 0;
    if (needMiniRedraw || millis() - miniTimer > 80)
    {
        updateMiniDisplays();
        needMiniRedraw = false;
        miniTimer = millis();
    }
}

// ==========================
// INIT
// ==========================
void menuBegin()
{
    // EQ Band Memory initialisieren
    for (int ch = 0; ch < MAX_CHANNELS; ch++)
    {
        for (int b = 0; b < MAX_EQ_BANDS; b++)
        {
            savedBandGain[ch][b] = 0.5f;  // 0dB default
            bandDisabled[ch][b]  = false;
        }
    }

    syncFadersToMixer();
    updateMiniDisplays();
    ui.redraw = true;
}