#pragma once
#include "config.h"

// ======================================================
// FADER-REGELUNG: "Drive → Brake → Coast → Accept"
// ======================================================
//
// Optimiert für: DRV8833 H-Bridge, 9V DC-Motor, ESP32-ADC
//
// DRV8833 Modi:
//   IN1=PWM, IN2=LOW  → Vorwärts (Slow Decay)
//   IN1=LOW, IN2=PWM  → Rückwärts (Slow Decay)
//   IN1=LOW, IN2=LOW  → Coast (Hi-Z, Motor läuft frei aus)
//   IN1=HIGH,IN2=HIGH → Brake (Low-Side kurzgeschlossen, Motor bremst aktiv)
//
// Ablauf:
//   DRIVE  → Motor läuft proportional Richtung Ziel
//   BRAKE  → DRV8833 Brake-Modus (beide HIGH), Motor stoppt aktiv
//   COAST  → DRV8833 Coast-Modus (beide LOW), Motor steht, ADC beruhigt sich
//   [NUDGE] → Optional: EIN kurzer Korrekturpuls
//   DONE   → Motor aus, Position akzeptiert, Takeover möglich
//
// ADC-Rauschen: Motor-PWM erzeugt EMI auf dem ADC.
//   Position wird während DRIVE nur grob genutzt (für Cutoff-Entscheidung).
//   Die präzise Positionsbestimmung erfolgt erst in COAST (Motor komplett aus).
//

// ---- Akzeptanzbereich ----
// Nach Coast: wenn Position hierin → fertig. ~0.6% des Weges, unhörbar.
#define ACCEPT_ZONE           25.0f

// Motor AUS wenn Fehler < CUTOFF_DISTANCE (VOR dem Ziel)
// Trägheit trägt den Rest. MUSS > ACCEPT_ZONE sein.
// Bei 9V Motor + DRV8833 brake: ~20-30 Counts Nachlauf
#define CUTOFF_DISTANCE       60.0f

// ---- Drive-Phase ----
#define DRIVE_KP              0.45f     // error * kP = PWM
#define DRIVE_MAX_PWM         200       // Nicht voll – weniger Overshoot
#define DRIVE_MIN_PWM         60        // 9V Motor braucht mehr als 3.3V Motor

// ---- Brake-Phase (DRV8833 aktive Bremse) ----
#define BRAKE_TIME_MS         75        // Beide Pins HIGH → Motor kurzgeschlossen

// ---- Coast-Phase (Motor frei, ADC beruhigt sich) ----
#define COAST_TIME_MS         60        // Warten bis ADC stabil

// ---- Nudge (einmalige Korrektur) ----
#define NUDGE_PWM             70
#define NUDGE_TIME_MS         35
#define NUDGE_ACCEPT          60.0f     // Nach Nudge: großzügiger akzeptieren

// ---- ADC ----
#define ADC_OVERSAMPLE        4
// Während DRIVE: schneller Filter (Motor-Rauschen tolerieren)
#define FILTER_ALPHA_DRIVE    0.5f
// Während COAST/DONE: langsamer Filter (saubere Messung)
#define FILTER_ALPHA_CLEAN    0.25f

// ---- Timeouts ----
#define MAX_MOVE_MS           1500

// ---- Block-Detection ----
#define BLOCK_MOVE_THRESHOLD  8.0f
#define BLOCK_TIMEOUT_MS      300
#define MAX_STUCK_COUNT       3

// ---- Takeover ----
#define TAKEOVER_THRESHOLD    60        // ~1.5% Bewegung = klar intentional
#define TAKEOVER_SETTLE_MS    100       // Warten nach DONE bevor Takeover möglich

// ---- Kalibrierung ----
#define CAL_PWM               170
#define CAL_MIN_TRAVEL        400
#define CAL_MIN_RANGE         1500
#define CAL_TIMEOUT_MS        4000
#define CAL_STOP_MS           180
#define CAL_STUCK_MS          600
#define CAL_MOVE_THRESHOLD    4

// ======================================================
// KLASSE
// ======================================================

class MotorFader
{
public:
    void     begin(uint8_t adcPin, uint8_t pinA, uint8_t pinB, uint8_t chA, uint8_t chB);
    void     update();

    void     setTarget(uint16_t value);
    uint16_t getPosition();
    uint16_t getTarget();
    bool     isAtTarget();
    bool     isMoving();

    uint32_t doneTime() const { return _doneTime; }

    void  calibrateStart(int direction);
    bool  calibrateTick();
    bool  calibrateFinish(uint16_t measuredMin, uint16_t measuredMax);

    bool     _calibrated  = false;
    bool     _calDone     = false;
    bool     _calSuccess  = false;
    uint16_t _calMeasured = 0;

private:
    enum State { IDLE, DRIVE, BRAKE, COAST, NUDGE, DONE };
    enum CalState { CAL_IDLE, CAL_GOING_UP, CAL_GOING_DOWN };

    State    _state    = IDLE;
    CalState _calState = CAL_IDLE;

    uint8_t _adcPin, _pinA, _pinB, _chA, _chB;

    float    _filtered     = 0;
    float    _position     = 0;
    float    _target       = 0;

    uint16_t _minPos = 0;
    uint16_t _maxPos = 4095;

    uint32_t _moveStartTime    = 0;
    uint32_t _brakeStartTime   = 0;
    uint32_t _coastStartTime   = 0;
    uint32_t _nudgeStartTime   = 0;
    uint32_t _doneTime         = 0;
    int      _nudgeDirection   = 0;

    uint32_t _lastProgressTime = 0;
    float    _lastProgressPos  = 0;
    int      _stuckCount       = 0;

    uint16_t _calStartPos = 0;
    uint16_t _calLastPos  = 0;
    uint32_t _calLastMove = 0;
    uint32_t _calStart    = 0;

    uint16_t readADC();
    void     motorForward(int pwm);
    void     motorReverse(int pwm);
    void     motorCoast();           // Beide LOW – Motor läuft frei
    void     motorBrake();           // Beide HIGH – aktive Bremse
    float    toScaled(float raw);
};

extern MotorFader faders[FADER_COUNT];

void     faderBegin();
void     faderLoop();
void     faderSet(uint8_t index, uint16_t value);
uint16_t faderGet(uint8_t index);
uint16_t faderGetTarget(uint8_t index);
bool     faderIsAtTarget(uint8_t index);
void     faderCalibrateAll();
